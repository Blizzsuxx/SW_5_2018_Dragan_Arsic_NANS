from Shape import Shape
import numpy as np


class Rect(Shape):

    def __init__(self, density, color, a, b, enviroment, sprite=False):
        super().__init__((a * b * b) * density, color, enviroment, sprite)
        self.a = a
        self.b = b
        self.density = density
        self.drag_constant = 1 / 2 * enviroment.density * Shape.C_CUBE * b**2
        self.inertia = self.mass * (self.a * self.a + self.b * self.b) / 12

    def getExtremities(self):
        extremities = []
        extremities.append(self.position)
        extremities.append(self.position + np.array([self.a, 0]))
        extremities.append(self.position + np.array([0, self.b]))
        extremities.append(self.position + np.array([self.a, self.b]))
        return np.array(extremities)

    def getNormals(self):
        normals = []
        extremities = self.getExtremities()
        v1 = extremities[0]
        v2 = extremities[1]
        v1 = v1 - v2
        v1 = v1 / np.sqrt(v1.dot(v1))
        normals.append(v1)
        v1 = extremities[0]
        v2 = extremities[2]
        v1 = v1 - v2
        v1 = v1 / np.sqrt(v1.dot(v1))
        normals.append(v1)
        return np.array(normals)

    def getBorder(self, direction):
        vector = np.array([self.a, self.b])
        value = np.linalg.norm(vector * direction)
        return value

    def getCenter(self):
        return self.position + np.array([self.a, -self.b])/2

    def move(self):
        pos = self.position - self.getCenter()
        self.torque = pos[0] * self.force[1] - pos[1] * self.force[0]
        self.angularspeed = self.angularspeed + Shape.DELTA_TIME * self.torque / self.inertia
        self.angle = self.angle + Shape.DELTA_TIME * self.angularspeed

        for i in range(len(self.vector)):
            self.vector[i] = self.vector[i] + Shape.DELTA_TIME * self.calculate_force(i)
            temp = Shape.DELTA_TIME * self.vector[i]
            self.position[i] = self.position[i] + int(temp + self.division_error[i])
            self.force[i] = 0

            self.division_error[i] += temp - int(temp) - int(self.division_error[i])

    def sign(self, i):
        force = self.force[i]
        if force == 0:
            vec = self.vector[i]
            if vec == 0:
                return 1
            else:
                return vec / abs(vec)
        return force / abs(force)

    def calculate_force(self, i):
        if i == 0:
            return ((self.force[i] - 1 / 2 * self.sign(i) * self.drag_constant * (
                    self.vector[i] + self.enviroment.velocity[i]) ** 2) / self.mass)
        else:
            return ((self.force[i] + self.mass * 9.81 - 1 / 2 * self.sign(i) * self.drag_constant * (
                    self.vector[i] + self.enviroment.velocity[i]) ** 2) / self.mass)
    
    def draw_pos(self):
        return (self.position[0], self.position[1], self.a, self.b)