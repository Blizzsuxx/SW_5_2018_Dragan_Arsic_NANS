import pygame

from Ball import Ball
from Fluid import Fluid
import numpy as np

from Rect import Rect


def main():
    WIDTH = 500
    HEIGTH = 500
    FORCE_VALUE = 100000
    DELAY_MILISECONDS = 17

    enviroment = Fluid(1.225, np.array([0, 0]))
    #ball = Ball(1, (250, 0, 0), 10, enviroment)
    ball = Rect(1, (250, 0, 0), 10, 10, enviroment)
    east_wall = Rect(1, (0,250,0), 5, HEIGTH, enviroment, True)
    east_wall.position[0] = WIDTH - 5
    east_wall.position[1] = 0

    west_wall = Rect(1, (0, 250, 0), 5, HEIGTH, enviroment, True)
    west_wall.position[0] = 0
    west_wall.position[1] = 0

    south_wall = Rect(1, (0, 250, 0), WIDTH, 5, enviroment, True)
    south_wall.position[0] = 0
    south_wall.position[1] = HEIGTH - 5

    north_wall = Rect(1, (0, 250, 0), WIDTH, 5, enviroment, True)
    north_wall.position[0] = 0
    north_wall.position[1] = 0

    enviroment.add(ball)
    enviroment.add(east_wall)
    enviroment.add(west_wall)
    enviroment.add(south_wall)
    enviroment.add(north_wall)

    pygame.init()
    window = pygame.display.set_mode( (WIDTH, HEIGTH))
    pygame.display.set_caption("Koralovo")
    while True:
        pygame.time.delay(DELAY_MILISECONDS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit(0)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            ball.left(FORCE_VALUE)
        if keys[pygame.K_RIGHT]:
            ball.right(FORCE_VALUE)
        if keys[pygame.K_UP]:
            ball.up(FORCE_VALUE)
        if keys[pygame.K_DOWN]:
            ball.down(FORCE_VALUE)
        ball.move()
        enviroment.collide()
        window.fill((0, 0, 250))
        #pygame.draw.circle(window, ball.color, ball.position, ball.radius, 1)
        for i in range(0, len(enviroment.shapes)):
            rect = enviroment.shapes[i]
            pygame.draw.rect(window,  rect.color, rect.draw_pos())
        pygame.display.update()





if __name__ == '__main__':
    main()
