import numpy as np


class Shape:
    DELTA_TIME = 0.016

    C_SPHERE = 0.47
    C_HALF_SPHERE = 0.42
    C_CONE = 0.50
    C_CUBE = 1.05
    C_ANGLED_CUBE = 0.80
    C_LONG_CYLINDER = 0.82
    C_SHORT_CYLINDER = 1.15
    C_STREAMLINED_BODY = 0.04
    C_STREAMLINED_HALF_BODY = 0.09

    def __init__(self, mass, color, enviroment, sprite=False):
        self.position = np.array([100, 100])
        self.force = np.array([0, 0])
        self.vector = np.array([0.0, 0.0])
        self.mass = mass
        self.color = color
        self.enviroment = enviroment
        self.sprite = sprite
        self.division_error = np.array([0.0, 0.0])
        self.inertia = 0
        self.torque = 0
        self.angle = np.array([0.0, 0.0])
        self.angularspeed = 0

    def move(self):
        pass

    def getBorder(self, direction):
        pass

    def getCenter(self):
        pass

    def left(self, force):
        self.force[0] -= force

    def right(self, force):
        self.force[0] += force

    def up(self, force):
        self.force[1] -= force

    def down(self, force):
        self.force[1] += force
