from Shape import Shape
from math import pi
import numpy as np


def skalar(n, d):
    s = 0
    for i in range(0,len(n)):
        s += n[i] * d[i]
    return s


class Ball(Shape):

    def __init__(self, density, color, radius, enviroment, sprite=False):
        super().__init__(((4/3) * pi * radius**3) * density, color, enviroment, sprite)
        self.radius = radius
        self.density = density
        self.drag_constant = 1/2 * enviroment.density * Shape.C_SPHERE * radius**2 * pi
        self.inertia = 1/4 * self.mass * self.radius * self.radius

    def getExtremities(self, normal):
        return [self.position + normal*self.radius, self.position - normal*self.radius]

    def getNormals(self):

        return np.array([[1.0, 0.0]])

    def getBorder(self, direction):
        return self.radius

    def move(self):
        #print(self.position, self.vector, self.force, self.mass)
        pos = self.position - self.radius
        self.torque = pos[0] * self.force[1] - pos[1] * self.force[0]
        self.angularspeed = self.angularspeed + Shape.DELTA_TIME * self.torque / self.inertia
        self.angle = self.angle + Shape.DELTA_TIME * self.angularspeed

        for i in range(len(self.vector)):

            self.vector[i] = self.vector[i] + Shape.DELTA_TIME * self.calculate_force(i)
            temp = Shape.DELTA_TIME * self.vector[i]
            self.position[i] = self.position[i] + int(temp + self.division_error[i])
            self.force[i] = 0

            self.division_error[i] += temp - int(temp) - int(self.division_error[i])

    def getCenter(self):
        return self.position

    def sign(self, i):
        force = self.force[i]
        if force == 0:
            vec = self.vector[i]
            if vec == 0:
                return 1
            else:
                return vec / abs(vec)
        return force / abs(force)

    def calculate_force(self, i):
        if i == 0:
            return ((self.force[i] - 1/2*self.sign(i) * self.drag_constant * (
                    self.vector[i] + self.enviroment.velocity[i]) ** 2) / self.mass)
        else:
            return ((self.force[i] + self.mass * 9.81 - 1/2*self.sign(i) * self.drag_constant * (
                    self.vector[i] + self.enviroment.velocity[i]) ** 2) / self.mass)
