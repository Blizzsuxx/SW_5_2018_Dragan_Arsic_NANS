
from Ball import Ball
from node import Node
import numpy as np

def projektuj(shape, n):
    if not isinstance(shape, Ball):
        extremi = shape.getExtremities()
    else:
        extremi = shape.getExtremities(n)
    levo = n.dot(extremi[0])
    desno = levo
    for i in range(1, len(extremi)):
        value = n.dot(extremi[i])
        if value < levo:
            levo = value
        if value > desno:
            desno = value
    return Node(levo, desno)


class Fluid:

    BETA = 0.5



    def __init__(self, density, velocity, shapes=[]):
        self.density = density
        self.velocity = velocity
        self.shapes = shapes

    def add(self, other):
        self.shapes.append(other)

    def check_coallision(self):

        the_list = []
        temp = None
        for i in range(0, len(self.shapes)):
            shape = self.shapes[i]
            for j in range(i+1, len(self.shapes)):
                other = self.shapes[j]
                if isinstance(shape, Ball):
                    if isinstance(other, Ball):
                        temp = self.check_balls(shape, other)
                    else:
                        temp = self.check_object_ball(shape, other)
                elif isinstance(other, Ball):
                    temp = self.check_object_ball(other, shape)
                else:
                    temp = self.checkObjectss(shape, other)
                if temp:
                    the_list.append(temp)
        return the_list

    def check_balls(self, shape, other):

        v = shape.getCenter() - other.getCenter()
        d = np.sqrt(v.dot(v))
        if (d - shape.radius - other.radius) < 0:
            v = v / np.sqrt(v.dot(v))
            return Node(v, d - (d - shape.radius) - other.radius, [shape, other])

        return None


    def checkObjectss(self, shape, other):
        if shape.sprite & other.sprite:
            return
        normale = shape.getNormals()
        if not isinstance(other, Ball):
            normale2 = (other.getNormals())
            normale = np.concatenate((normale, normale2))
        biggest_d = -float("inf")
        inner_most_extreme = None
        for n in normale:
            p1 = projektuj(shape, n)
            p2 = projektuj(other, n)
            d = p1.inRange(p2)
            if d is None:
                return
            if d > biggest_d:
                biggest_d = d
                inner_most_extreme = n
        return Node(inner_most_extreme, biggest_d, [shape, other])

    def check_object_ball(self, ball, other):
        if ball.sprite & other.sprite:
            return
        normale = []
        normale.extend(other.getNormals())
        lista = []
        the_list = []
        e1 = ball.getCenter()
        for e2 in other.getExtremities():
            broken = False
            for n in normale:
                d = e2 - e1
                p = abs(n.dot(d))
                s = p - ball.radius
                if s >= 0:
                    broken = True
                    break
                else:
                    lista.append(Node(s, n, [ball, other]))
            if not broken:
                lista.sort()
                the_list.append(lista[0])
            else:
                lista.clear()

        if the_list:
            the_list.sort()
            return the_list[0]
        else:
            return self.checkObjectss(other, ball)




    def collide(self):
        coallisions = self.check_coallision()
        if not coallisions:
            return

        print(coallisions[0].value2)

        """
        n_new = np.zeros((len(coallisions), len(coallisions)*2 + 2))
        v_new = np.zeros(len(coallisions)*2 + 2)
        s_new = np.zeros(len(coallisions))
        m_new = np.zeros((len(coallisions)*2 + 2, len(coallisions)*2 + 2))
        f_new = np.zeros(len(coallisions)*2 + 2)
        for i in range(len(coallisions)):
            j = i*2
            c = coallisions[i]
            n_new[i][j] = -c.value2[0]
            n_new[i][j+1] = -c.value2[1]
            n_new[i][j + 2] = c.value2[0]
            n_new[i][j + 3] = c.value2[1]
            s_new[i] = c.value1
            o1 = c.items[0]
            o2 = c.items[1]
            v_new[j] = o1.vector[0]
            v_new[j+1] = o1.vector[1]
            v_new[j+2] = o2.vector[0]
            v_new[j+3] = o2.vector[1]
            m_new[j][j] = o1.mass
            m_new[j+1][j + 1] = o1.mass
            m_new[j+2][j + 2] = o2.mass
            m_new[j+3][j + 3] = o2.mass
            f_new[j] = o1.force[0]
            f_new[j + 1] = o1.force[1]
            f_new[j + 2] = o2.force[0]
            f_new[j + 3] = o2.force[1]
        n_dot_m = n_new.dot(1/m_new)
        A = n_dot_m.dot(n_new.T)
        print(n_dot_m, "aaaaaaaaa")
        print(n_new, "bbbbbbbbbbb")
        p1 = -Fluid.BETA * (1 / Shape.DELTA_TIME**2)*s_new
        p2 = 1/Shape.DELTA_TIME * n_new.dot(v_new)
        try:
            p3 = n_dot_m.dot(f_new)
        except:
            p3 = n_dot_m * f_new
        b = p1 - p2 - p3
        print(A)
        print(b)
        x = np.linalg.solve(A, b)
        """

    """ def check_object_ball(self, ball, other):
            edges = other.getExtremities()
            min_d = float('inf')
            min_e = None
            for e in edges:
                a = ball.position - e
                d = np.sqrt(a.dot(a))

                if d > ball.radius:
                    continue

                if d < min_d:
                    min_d = d
                    min_e = e
            if min_e is None:
                return
            return Node(min_d, min_e, [ball, other])"""